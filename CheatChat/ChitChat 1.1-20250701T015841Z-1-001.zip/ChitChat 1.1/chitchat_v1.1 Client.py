import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, simpledialog

def send_message():
    recipient = recipient_entry.get().strip()
    message = message_entry.get().strip()
    if recipient and message:
        client_socket.sendall(b"TEXT      ")
        client_socket.sendall(recipient.ljust(20).encode())
        client_socket.sendall(message.encode())
        chat_display.config(state=tk.NORMAL)
        chat_display.insert(tk.END, f"You to {recipient}: {message}\n")
        chat_display.config(state=tk.DISABLED)
        message_entry.delete(0, tk.END)

def create_group():
    group_name = simpledialog.askstring("Create Group", "Enter group name:")
    if group_name:
        client_socket.sendall(b"GROUP_CREATE")
        client_socket.sendall(group_name.ljust(20).encode())

def join_group():
    group_name = simpledialog.askstring("Join Group", "Enter group name:")
    if group_name:
        client_socket.sendall(b"GROUP_JOIN ")
        client_socket.sendall(group_name.ljust(20).encode())

def receive_messages():
    while True:
        try:
            header = client_socket.recv(10).decode().strip()
            if not header:
                break
            
            sender = client_socket.recv(20).decode().strip()
            message = client_socket.recv(1024).decode()
            
            chat_display.config(state=tk.NORMAL)
            chat_display.insert(tk.END, f"{sender}: {message}\n")
            chat_display.config(state=tk.DISABLED)
        except:
            break

def start_client():
    global client_socket, root, chat_display, recipient_entry, message_entry

    HOST = simpledialog.askstring("Server", "Enter server IP:")
    PORT = 65432
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    
    username = simpledialog.askstring("Username", "Enter your username:")
    client_socket.sendall(username.ljust(20).encode())

    threading.Thread(target=receive_messages, daemon=True).start()

    root = tk.Tk()
    root.title(f"Chat - {username}")

    chat_display = scrolledtext.ScrolledText(root, width=50, height=20, wrap=tk.WORD)
    chat_display.grid(row=0, column=0, columnspan=3, padx=10, pady=10)
    chat_display.config(state=tk.DISABLED)

    recipient_label = tk.Label(root, text="Recipient:")
    recipient_label.grid(row=1, column=0, padx=5, pady=5)

    recipient_entry = tk.Entry(root, width=20)
    recipient_entry.grid(row=1, column=1, padx=5, pady=5)

    message_entry = tk.Entry(root, width=40)
    message_entry.grid(row=2, column=0, padx=10, pady=10)

    send_button = tk.Button(root, text="Send", width=10, command=send_message)
    send_button.grid(row=2, column=1, padx=10, pady=10)

    group_create_button = tk.Button(root, text="Create Group", width=15, command=create_group)
    group_create_button.grid(row=3, column=0, padx=10, pady=10)

    group_join_button = tk.Button(root, text="Join Group", width=15, command=join_group)
    group_join_button.grid(row=3, column=1, padx=10, pady=10)

    root.mainloop()

if __name__ == "__main__":
    start_client()
