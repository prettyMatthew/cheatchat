import firebase_admin
from firebase_admin import credentials, firestore
import uuid

# Initialize Firebase app
cred = credentials.Certificate("chitchat-e4fc8-firebase-adminsdk-fbsvc-db60c7e3a6.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

def get_device_id():
    return str(uuid.getnode())  # Unique per device

def get_user_profile():
    device_id = get_device_id()
    doc_ref = db.collection("users").document(device_id)
    doc = doc_ref.get()
    if doc.exists:
        return doc.to_dict()['username']
    else:
        username = input("Enter your username: ")
        doc_ref.set({'username': username})
        return username

# Usage
username = get_user_profile()
print(f"Welcome, {username}!")