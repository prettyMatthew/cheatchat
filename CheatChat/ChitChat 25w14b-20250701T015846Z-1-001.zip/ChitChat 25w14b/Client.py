import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, simpledialog
from datetime import datetime
import webbrowser

shift_press_count = [0]


def send_message():
    recipient = recipient_entry.get().strip()
    message = message_entry.get().strip()

    if recipient and message:
        client_socket.sendall(b"TEXT ")
        client_socket.sendall(recipient.ljust(20).encode())
        client_socket.sendall(message.encode())

        time_str = datetime.now().strftime("%H:%M")
        chat_display.config(state=tk.NORMAL)
        chat_display.insert(tk.END, f"You to {recipient} ({time_str}): {message} ✓\n")
        chat_display.tag_add('sent', "end-2l", "end-1c")
        chat_display.tag_config('sent', foreground="black", background="lightyellow", justify='right', lmargin1=150,
                                rmargin=5)
        chat_display.config(state=tk.DISABLED)

        message_entry.delete(0, tk.END)


def create_group():
    group_name = simpledialog.askstring("Create Group", "Enter group name:")

    if group_name:
        group_window = tk.Toplevel(root)
        group_window.title(f"Group Chat - {group_name}")
        group_display = scrolledtext.ScrolledText(group_window, width=50, height=20, wrap=tk.WORD)
        group_display.grid(row=0, column=0, columnspan=3, padx=10, pady=10)
        group_display.config(state=tk.DISABLED)

        group_message_entry = tk.Entry(group_window, width=40)
        group_message_entry.grid(row=1, column=0, padx=10, pady=10)

        group_send_button = tk.Button(group_window, text="Send", width=10,
                                      command=lambda: send_group_message(group_name, group_message_entry,
                                                                         group_display))
        group_send_button.grid(row=1, column=1, padx=10, pady=10)

        client_socket.sendall(b"GROUP_CREATE")
        client_socket.sendall(group_name.ljust(20).encode())


def send_group_message(group_name, group_message_entry, group_display):
    message = group_message_entry.get().strip()

    if message:
        client_socket.sendall(b"GROUP_TEXT")
        client_socket.sendall(group_name.ljust(20).encode())
        client_socket.sendall(message.encode())

        time_str = datetime.now().strftime("%H:%M")
        group_display.config(state=tk.NORMAL)
        group_display.insert(tk.END, f"You to {group_name} ({time_str}): {message} ✓\n")
        group_display.tag_add('sent', "end-2l", "end-1c")
        group_display.tag_config('sent', foreground="black", background="lightyellow", justify='right', lmargin1=150,
                                 rmargin=5)
        group_display.config(state=tk.DISABLED)

        group_message_entry.delete(0, tk.END)


def join_group():
    group_name = simpledialog.askstring("Join Group", "Enter group name:")
    if group_name:
        client_socket.sendall(b"GROUP_JOIN ")
        client_socket.sendall(group_name.ljust(20).encode())


def receive_messages():
    while True:
        try:
            header = client_socket.recv(10).decode().strip()
            if not header:
                break

            sender = client_socket.recv(20).decode().strip()
            message = client_socket.recv(1024).decode()

            if header == "USER_LIST":
                update_user_list(message)
            else:
                time_str = datetime.now().strftime("%H:%M")
                chat_display.config(state=tk.NORMAL)
                chat_display.insert(tk.END,f"{message.split()[1]} to you: {message.split()[2]} ({time_str})")
                #chat_display.insert(tk.END, f"{sender} ({time_str}): {message}\n")
                chat_display.tag_add('received', "end-2l", "end-1c")
                chat_display.tag_config('received', foreground="white", background="gray", justify='left', lmargin1=5,
                                        rmargin=150)
                chat_display.config(state=tk.DISABLED)

        except:
            break


def update_user_list(user_list):
    users = user_list.split(',')
    user_list_window = tk.Toplevel(root)
    user_list_window.title("Users Online")
    user_display = tk.Label(user_list_window, text="\n".join(users), padx=20, pady=20)
    user_display.pack()


def show_user_list(event):
    client_socket.sendall(b"USER_LIST_REQ")


def on_key_press(event):
    if event.keysym in ['Shift_L', 'Shift_R']:
        shift_press_count[0] += 1
        root.after(1000, lambda: shift_press_count.__setitem__(0, 0))
        if shift_press_count[0] >= 3:
            webbrowser.open("https://classroom.google.com")
            shift_press_count[0] = 0


def start_client():
    global client_socket, root, chat_display, recipient_entry, message_entry, user_count_label

    HOST = simpledialog.askstring("Server", "Enter server IP:")
    PORT = 65432
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))

    username = simpledialog.askstring("Username", "Enter your username:")
    client_socket.sendall(username.ljust(20).encode())

    threading.Thread(target=receive_messages, daemon=True).start()

    root = tk.Tk()
    root.title(f"Chat - {username}")

    chat_display = scrolledtext.ScrolledText(root, width=50, height=20, wrap=tk.WORD)
    chat_display.grid(row=0, column=0, columnspan=3, padx=10, pady=10)
    chat_display.config(state=tk.DISABLED)

    recipient_label = tk.Label(root, text="Recipient:")
    recipient_label.grid(row=1, column=0, padx=5, pady=5)

    recipient_entry = tk.Entry(root, width=20)
    recipient_entry.grid(row=1, column=1, padx=5, pady=5)

    message_entry = tk.Entry(root, width=40)
    message_entry.grid(row=2, column=0, padx=10, pady=10)

    send_button = tk.Button(root, text="Send", width=10, command=send_message)
    send_button.grid(row=2, column=1, padx=10, pady=10)

    group_create_button = tk.Button(root, text="Create Group", width=15, command=create_group)
    group_create_button.grid(row=3, column=0, padx=10, pady=10)

    group_join_button = tk.Button(root, text="Join Group", width=15, command=join_group)
    group_join_button.grid(row=3, column=1, padx=10, pady=10)

    user_count_label = tk.Label(root, text="Users Online: 0", bg="lightgrey", anchor="w")
    user_count_label.grid(row=4, column=0, columnspan=3, sticky="w", padx=10, pady=5)
    user_count_label.bind("<Button-1>", show_user_list)

    root.bind_all("<KeyPress>", on_key_press)

    root.mainloop()


if __name__ == "__main__":
    start_client()
