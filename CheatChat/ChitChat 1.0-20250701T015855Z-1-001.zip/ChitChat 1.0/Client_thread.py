import socket
import threading
import sys

# Function to handle receiving messages
def receive_messages(s):
    while True:
        try:
            data = s.recv(1024)
            if not data:
                print("\nConnection closed by server.")
                break
            # Move cursor up and overwrite input line with new message
            sys.stdout.write(f"\r{host_name}: {data.decode()}\n{client_name.decode()}: ")
            sys.stdout.flush()
        except:
            break

# Function to handle sending messages
def send_messages(s):
    while True:
        message = input(f"{client_name.decode()}: ")
        if message.lower() == "exit":
            print("Closing connection...")
            s.close()
            break
        s.sendall(message.encode())

def start_client():
    global host_name, client_name  # Make these accessible in functions

    PORT = 65432
    HOST = input('Please enter the server IP: ')

    print()

    client_name = input('Enter your username: ').encode()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))  # Connect to the server
        s.sendall(client_name)  # Send the client's username to the server
        host_name = s.recv(1024).decode()  # Receive the host's name from the server

        print(f"Connected to {host_name}. Type 'exit' to leave the chat.")

        # Start receiving messages in a separate thread
        threading.Thread(target=receive_messages, args=(s,), daemon=True).start()

        # Start sending messages in the main thread
        send_messages(s)

if __name__ == "__main__":
    start_client()