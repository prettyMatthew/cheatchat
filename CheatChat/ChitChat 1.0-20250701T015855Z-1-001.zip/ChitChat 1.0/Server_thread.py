import socket
import threading
import sys

# Function to handle receiving messages from the client
def receive_messages(conn, client_name):
    while True:
        try:
            data = conn.recv(1024)
            if not data:
                print(f"\n{client_name} has disconnected.")
                break
            # Move cursor up and overwrite input line with new message
            sys.stdout.write(f"\r{client_name}: {data.decode()}\n{host_name}: ")
            sys.stdout.flush()
        except:
            break

# Function to handle sending messages to the client
def send_messages(conn):
    while True:
        message = input(f"{host_name}: ")
        if message.lower() == "exit":
            print("Closing connection...")
            conn.close()
            break
        conn.sendall(message.encode())

def start_server():
    global host_name  # Make this accessible in functions

    HOST = str(input('Please enter the server IP: '))
    PORT = 65432
    host_name = input("Enter your username: ")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"Server started at {HOST}:{PORT}, waiting for connections...")

        conn, addr = s.accept()
        with conn:
            print(f"Connected by {addr}")
            client_name = conn.recv(1024).decode()  # Receive the client's username
            conn.sendall(host_name.encode())  # Send the server's username to the client

            print(f"Chat started with {client_name}. Type 'exit' to end the chat.")

            # Start receiving messages in a separate thread
            threading.Thread(target=receive_messages, args=(conn, client_name), daemon=True).start()

            # Start sending messages in the main thread
            send_messages(conn)

if __name__ == "__main__":
    start_server()
