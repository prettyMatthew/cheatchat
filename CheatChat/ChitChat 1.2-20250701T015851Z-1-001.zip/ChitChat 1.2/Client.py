import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, simpledialog
from tkinter import ttk


def send_message():
    recipient = recipient_entry.get().strip()
    message = message_entry.get().strip()
    if recipient and message:
        # Sending the "TEXT" header, recipient, and message
        client_socket.sendall(b"TEXT      ")  # Header for text message
        client_socket.sendall(recipient.ljust(20).encode())  # Recipient padded to 20 chars
        client_socket.sendall(message.encode())  # Message content
        chat_display.config(state=tk.NORMAL)
        chat_display.insert(tk.END, f"You to {recipient}: {message}\n")
        chat_display.config(state=tk.DISABLED)
        message_entry.delete(0, tk.END)


def create_group():
    group_name = simpledialog.askstring("Create Group", "Enter group name:")
    if group_name:
        tab2 = ttk.Frame(ttk.Notebook(root))
        ttk.Notebook(root).add(tab2, text=group_name)


def join_group():
    group_name = simpledialog.askstring("Join Group", "Enter group name:")
    if group_name:
        client_socket.sendall(b"GROUP_JOIN ")
        client_socket.sendall(group_name.ljust(20).encode())


def receive_messages():
    while True:
        try:
            # Receive the header and ensure it is "TEXT"
            header = client_socket.recv(10).decode().strip()
            if header == "TEXT":
                # Get the recipient and message
                recipient = client_socket.recv(20).decode().strip()
                message = client_socket.recv(1024).decode()

                # Display the message in the chat window
                chat_display.config(state=tk.NORMAL)

                # If the recipient is the current user, it's a message for them
                if recipient == username:
                    chat_display.insert(tk.END, f"{header} to you: {message}\n")
                else:
                    chat_display.insert(tk.END, f"{recipient} to you: {message}\n")

                chat_display.config(state=tk.DISABLED)
        except:
            break


def start_client():
    global client_socket, root, chat_display, recipient_entry, message_entry, username

    HOST = simpledialog.askstring("Server", "Enter server IP:")
    PORT = 58395
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))

    username = simpledialog.askstring("Username", "Enter your username:")
    client_socket.sendall(username.ljust(20).encode())  # Send the username to the server

    threading.Thread(target=receive_messages, daemon=True).start()

    root = tk.Tk()
    root.title(f"Chat - {username}")

    chat_display = scrolledtext.ScrolledText(root, width=50, height=20, wrap=tk.WORD)
    chat_display.grid(row=0, column=0, columnspan=3, padx=10, pady=10)
    chat_display.config(state=tk.DISABLED)

    recipient_label = tk.Label(root, text="Recipient:")
    recipient_label.grid(row=1, column=0, padx=5, pady=5)

    recipient_entry = tk.Entry(root, width=20)
    recipient_entry.grid(row=1, column=1, padx=5, pady=5)

    message_entry = tk.Entry(root, width=40)
    message_entry.grid(row=2, column=0, padx=10, pady=10)

    send_button = tk.Button(root, text="Send", width=10, command=send_message)
    send_button.grid(row=2, column=1, padx=10, pady=10)

    group_create_button = tk.Button(root, text="Create Group", width=15, command=create_group)
    group_create_button.grid(row=3, column=0, padx=10, pady=10)

    group_join_button = tk.Button(root, text="Join Group", width=15, command=join_group)
    group_join_button.grid(row=3, column=1, padx=10, pady=10)

    tab_parent = ttk.Notebook(root, width=800, height=500)

    tab1 = ttk.Frame(root)
    tab_parent.add(tab1, text='Main')

    root.mainloop()


if __name__ == "__main__":
    start_client()