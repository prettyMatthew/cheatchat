import socket
import threading

clients = {}  # {username: connection}
groups = {}  # {group_name: [usernames]}

lock = threading.Lock()


def handle_client(conn, username):
    try:
        while True:
            header = conn.recv(10).decode().strip()
            if not header:
                break

            if header == "TEXT":
                recipient = conn.recv(20).decode().strip()
                message = conn.recv(1024).decode()
                if recipient.startswith("#"):
                    send_group_message(username, recipient, message)
                else:
                    send_private_message(username, recipient, message)
            elif header == "GROUP_JOIN":
                group_name = conn.recv(20).decode().strip()
                join_group(username, group_name)
            elif header == "GROUP_CREATE":
                group_name = conn.recv(20).decode().strip()
                create_group(username, group_name)
    except:
        pass
    finally:
        with lock:
            del clients[username]
        conn.close()
        print(f"{username} has disconnected.")


def send_private_message(sender, recipient, message):
    if recipient in clients:
        try:
            clients[recipient].sendall(f"TEXT      {sender.ljust(20)}{message}".encode())
        except:
            pass


def send_group_message(sender, group_name, message):
    with lock:
        if group_name in groups:
            members = groups[group_name]
            for member in members:
                if member in clients and member != sender:
                    try:
                        clients[member].sendall(f"TEXT      {group_name} - {sender.ljust(20)}{message}".encode())
                    except:
                        pass


def create_group(username, group_name):
    with lock:
        if group_name not in groups:
            groups[group_name] = [username]
            print(f"Group {group_name} created by {username}")


def join_group(username, group_name):
    with lock:
        if group_name in groups:
            if username not in groups[group_name]:
                groups[group_name].append(username)
                print(f"{username} joined {group_name}")


def start_server():
    HOST = input("Enter the IP address to host the server (e.g., '0.0.0.0'): ").strip()
    PORT = int(input("Enter the port number (e.g., 65432): ").strip())
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen()
    print(f"Server started at {HOST}:{PORT}, waiting for connections...")

    while True:
        conn, addr = server_socket.accept()
        conn.sendall("Enter your username: ".encode())
        username = conn.recv(20).decode().strip()

        with lock:
            clients[username] = conn

        print(f"{username} has joined the chat.")
        threading.Thread(target=handle_client, args=(conn, username), daemon=True).start()


if __name__ == "__main__":
    start_server()